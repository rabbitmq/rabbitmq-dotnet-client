def SublanguageHandler(args, doc, renderer):
    pass
