import Inline

def SpanHandler(rest, acc):
    return Inline.discardSpan(rest)
