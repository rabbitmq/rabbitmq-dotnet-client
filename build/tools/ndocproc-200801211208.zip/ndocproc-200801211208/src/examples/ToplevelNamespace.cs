///<summary>This class resides in the toplevel, empty namespace.</summary>
public class OutsideAllNamespaces {
    ///<summary>Construct a default instance.</summary>
    public OutsideAllNamespaces() {}

    ///<summary>I perform some foo task.</summary>
    public void Foo() {}

    ///<summary>Gets a OneHello instance</summary>
    public net.lshift.ndocproc.examples.one.OneHello GetHello() { return null; }
}